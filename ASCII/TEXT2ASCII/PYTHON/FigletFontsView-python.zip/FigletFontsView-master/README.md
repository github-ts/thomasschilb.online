# FigletFontsView

[examples](https://github.com/spaceack/FigletFontsView/blob/master/examples.html)

[flf-fonts](https://github.com/pwaller/pyfiglet/tree/master/pyfiglet/fonts)

Run:
```
Python3 flf-fonts-view.py fonts_dir_path > examples.html
```
