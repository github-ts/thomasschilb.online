This directory contains two programs:

 FIGWin -  (Beta copy) A Windows clone of FIGlet which includes vertical
           smushing capability.

              * NOTE: FIGWin, though it is FIGlet compatible, is NOT
                FIGlet. It is a different program by a different person
                that does the same thing, but with a Windows GUI.

 Anyfont - A small utility which converts ASCII art for proportional
           Windows fonts by inserting spaces into the art so that
           everything still lines up.

TO DOWNLOAD THESE PROGRAMS:
    
    Download: fgwnbeta.zip or anyfont.zip (whichever you prefer)

    ***ALSO***

    Check your computer.  If your computer has a file called vbrun300.dll
    in the \windows\system directory, you're fine.  If not, then you will
    also have to download:

              vbrun300.dll
                     ...or...
              vbrun300.zip (if you prefer zipped format)

TO INSTALL THESE PROGRAMS:

    Place vbrun300.dll in your \windows\system directory if you didn't
    already have it.

    IF YOU DOWNLOADED FIGWIN:
    Place fgwnbeta.exe in any directory you like.  FIGfont files (*.flf) 
    should be in the same directory.

    IF YOU DOWNLOADED ANYFONT:
    Place anyfont.exe in any directory you like.

TO RUN THESE PROGRAMS:

    Just run the files, either fgwnbeta.exe or anyfont.exe!

TO UNINSTALL:

    Just delete the same files!  (You should probably leave vbrun300.dll
    in your \windows\system directory in case you download programs in
    the future which are written in Visual Basic 3.0 -- they won't run
    without it.)

