     _                                              _
   .\_/. -=======================================- .\_/.
   ||a||  |  JavE (Java Ascii Versatile Editor) |  ||a||
   `/_\' -=======================================- `/_\'

-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-

To install this software:
-------------------------

 - Install a Java Runtime Environment 1.6 or greater
   It can be downloaded for free from http://java.sun.com/getjava/

 - Unpack the JavE download archive to a new folder.

To run the software:
--------------------

 - Double click on jave.jar or jave.bat in the installation folder
   or start it from the command line using the command
      java -jar jave.jar

For Questions:
--------------
 - See the FAQ at http://www.jave.de/docs/faq.html

-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-

Contact:
--------

Feel free to contact me at markus@jave.de

Further informations, updates, etc.: http://www.jave.de

Markus Gebhard, markus@jave.de, 2009