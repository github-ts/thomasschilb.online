Configuration files for JavE greyscale tables
Do not modify or delete those files!