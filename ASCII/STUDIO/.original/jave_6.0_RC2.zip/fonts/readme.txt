This folder is intended for FIGlet fonts.
  _____ ___ ____ _      _      _____          _ 
 |  ___|_ _/ ___| | ___| |_   |  ___|__  _ __ | |_ ___
 | |_   | | |  _| |/ _ \ __|  | |_ / _ \| '_ \| __/ __|
 |  _|  | | |_| | |  __/ |_   |  _| (_) | | | | |_\__ \
 |_|   |___\____|_|\___|\__|  |_|  \___/|_| |_|\__|___/

You can download them from:
  http://www.jave.de/figlet/fonts.html
  
Additional fonts can be added by simply copying them into this folder.
Fonts are sorted into categories by the file categoriestree.txt.