Pe Icon Changer by Chris Gingerich
Web: http://Starpunch.net
Email: starpunch.net@gmail.com

PE Icon Changer allows the user to change the main icon of an EXE file.

To Use:
No install. Open the ZIP file and run PEIconChanger.exe. Select the EXE to change and the EXE or ICON to use. Then press OK.
You may need to reboot the see the correct icon of the changed EXE as the icon for the EXE is cached in the windows system.

Note:
Please only use icon files that have 16, 32, 48 icon sizes. Larger sizes may cause PE Icon Changer to crash.

PE Icon Changer is freeware