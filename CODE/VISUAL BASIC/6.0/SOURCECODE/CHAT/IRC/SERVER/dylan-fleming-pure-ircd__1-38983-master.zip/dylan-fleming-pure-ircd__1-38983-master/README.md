﻿<div align="center">

## PURE IRCd


</div>

### Description

PURE Internet Relay Chat daemon was created for the purpose of providing Windows server administrators with a method of implementing an IRCd that was not only easy to work with and alter but also developed solely for Windows enviorment.

This is actually a compilation of code from JoeyJoey which can be found at:

http://www.planetsourcecode.com/vb/scripts/ShowCode.asp?txtCodeId=35898&lngWId=1

and from Dennis Fisch which can be found at:

http://www.planetsourcecode.com/vb/scripts/ShowCode.asp?txtCodeId=38086&lngWId=1

This is an on going project.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2002-09-14 01:13:10
**By**             |[Dylan Fleming](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/dylan-fleming.md)
**Level**          |Intermediate
**User Rating**    |5.0 (20 globes from 4 users)
**Compatibility**  |VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[PURE\_IRCd1309729142002\.zip](https://github.com/Planet-Source-Code/dylan-fleming-pure-ircd__1-38983/archive/master.zip)








