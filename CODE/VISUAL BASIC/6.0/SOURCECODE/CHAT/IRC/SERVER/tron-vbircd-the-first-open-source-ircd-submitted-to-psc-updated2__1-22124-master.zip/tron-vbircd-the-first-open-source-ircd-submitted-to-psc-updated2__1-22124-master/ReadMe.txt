
 NOTICE: THIS PROJECT IS UNDER THE GENERAL PUBLIC LICENSE (GPL)
         FOR MORE INFORMATION ON THIS PGL AGREEMENT THEN OPEN
         THE FILE LICENSE.txt THAT SHOULD HAVE CAME WITH THIS
         ZIPPED FILE AND IF NOT THEN DO NOT RUN NOR USE CODE.

         BUT INSTEAD VISIT http://www.planet-source-code.com/vb
         AND SEARCH FOR 'vbIRCd' AND SHOULD GET A RESULT AND THEN
         DOWNLOAD THE ZIP FILE AND USE THAT INSTEAD AND DELETE
         THIS, THE ZIPPED FILE THAT THIS CAME WITH AND ALL OF IT'S
         FILES ONLY.

####################################################################
# Read Me File Information About the Source Code that was Released #
####################################################################
#                                                                  #
#  Project Name: vbIRCd          Date Release: [03/23/2001]        #
#  Code Version: v1.0.48       Project Author: TRON(Nathan Martin) #
# Update Number: 2nd           Update Release: [04/09/2001]        #
#                                                                  #
# Does author wish to be voted for code: Yeah! This thing is great!#
#                                                                  #
####################################################################

####################################################################
# Project Support Information for getting problems resolved quick! #
####################################################################
#                                                                  #
# You can only get support for vbIRCd currently through IRC on the #
# Unreal IRCd IRC Server which is irc.unrealircd.com  and join the #
# channel #vbIRCd and ask your questions there about vbIRCd related#
# questions ONLY Please...                                         #
#                                                                  #
#     SITE COMING SOON FOR vbIRCd @ http://vbircd.ircd-net.org     #
#                                                                  #
####################################################################

####################################################################
#       Information About the Author and Contact Inforamtion       #
####################################################################
#                                                                  #
#      Author's Full Name:  Nathan Martin                          #
#      Author's Nick Name:  TRON                                   #
# Author's E-mail Address:  tron@ircd-net.org                      #
#   Author's Web Site URL:  http://t2n.dyndns.org                  #
#  IRC Server Author uses:  irc.ircd-net.org, jolt.horizonws.org   #
# IRC Channel commonly on:  #IRCdNet, #TRON                        #
# ---------------------------------------------------------------- #
# About Author: I'm a good Client/Server Developer in Visual Basic #
#               and currently learning C/C++, but enough to fix or #
#               edit C/C++ code to make it kinda better or fixed ;)#
#                                                                  #
#               That's  all I have  to say, I don't  have anything #
#               really interesting to say, but  that I do  like to #
#               work with Red Hat linux OSs for internet stuff and #
#               that I love programming every day, almost 24/7 ;D  #
#                                                                  #
####################################################################

####################################################################
# Description About the Released Soure Code and What it all can do #
####################################################################
#                                                                  #
# vbIRCd is a IRC Server written in Visual Basic 6 that normal IRC #
# clients like mIRC, vIRC,  BitchX,  Pirch,  Turbo IRC and etc can #
# use vbIRCd just like they can use wIRCd, UnrealIRcd, IRC Serv, & #
# etc..  vbIRCd is the first IRCd to be posted at PSC.          :) #
#                                                                  #
####################################################################

####################################################################
# The Author's Comments and Related Info About relased Source code #
####################################################################
#                                                                  #
# vbIRCd was created just because I felt I needed to do something  #
# about  releasing an  IRCd that  was working  without bugs on PSC #
# since  no one has  yet to release a  IRCd written in VB that was #
# working like it's suppose to and I think I made the right choase # 
# since  allot of people  are going to find  this source code very #
# useful and I think allot of people will thank me for doing so :) #
#                                                                  #
# vbIRCd is really a stripped down version of IRC Serv which  is a #
# big project I've been working on for about close to 3years and I #
# have found many ways of developing the IRCd without having to do #
# allot of coding nor allot of researching to find how to do  this #
# and such.  I found that I learned allot from just developing the #
# IRC Serv project by thinking thru the coding process and figuring#
# out how I'm going to get a feature functioning without any bugs  #
# nor problems and I've done so.                                   #
#                                                                  #
# I would like so say that vbIRCd is not considered IRC Serv since #
# it is in fact stripped down, so it's basicly been stripped from  #
# the title IRC Serv to vbIRCd which is it's title, but considered #
# a clone of IRC Serv since it's code is from and based right off  #
# of IRC Serv. :)                                                  #
#                                                                  #
####################################################################

####################################################################
#   Related Links and Information About this Source Code Project   #
####################################################################
#                                                                  #
# IRC Server Project that I'm currently working on that's cool :)  #
# URL: http://www.irc-serv.com And http://www.ircd-net.org/ircserv #
#                                                                  #
# The best Visual Basic and other porgramming sources on the Net!! #
# URL: http://www.planet-source-code.com/vb/ - Open Source rules!  #
#                                                                  #
# My network web site that I most of the time release my code on   #
# URL: http://t2n.dyndns.org  and  http://wwww.t2n.org             #
#                                                                  #
####################################################################

####################################################################
# Non-Related Links to the source code and Information from Author #
####################################################################
#                                                                  #
# IRCd-Net and Horizon IRC, my IRC home and creation =)            #
# URL: http://www.ircd-net.org  and  http://www.horizonws.org      #
# Note: ircd-net.org is also soon to be a IRCd Help Guide site! :) #
#                                                                  #
# One of the best Linux Information sites I've ever seen!          #
# URL: http://linux.box.sk - This is better then linuxdoc.org ;p   #
#                                                                  #
####################################################################