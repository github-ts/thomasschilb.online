Cina Proxy Server Project
=========================
Version: stablev07
README file updated on: 2003-03-04
LICENSE: GNU GPL see LICENSE.txt for details

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

Copyright (c) 2000-2003 by Philipp Rothmann ".) Development". All Rights Reserved.

Author: Philipp Rothmann mailto: dev@preneco.de

==============================================================================

This distribution contains public domain DES software by Richard Outerbridge.
This is:
Copyright (c) 1988,1989,1990,1991,1992 by Richard Outerbridge.
(GEnie : OUTER; CIS : [71755,204]) Graven Imagery, 1992.
==============================================================================


please visit the projects webpage hosted at sourceforge.org 
http://www.cinaproxy.de.vu for documentation and new releases..

Table of Contents
-----------------

  1. Introduction
  2. Compiling Instruction (see COMPILE.txt)
  3. Known issues
  4. Documentation (available at http://www.cinaproxy.de.vu)


Introduction
------------

OS: Windows 2k/XP (9x,ME,NT)
PL: Visual Basic 6.0

This software is a Visual Basic 6.0 implemented All-In-One LAN-to-WAN Server
that uses the object model features to comply to the RFC Internet Protocol indicies.

The Cina Proxy provides Internet access via a single modem, ISDN or DSL connection, for a group of LAN users. It is installed on the machine where the analog, ISDN or DSL-modem is plugged in and acts as the server. 
An HTTP server is included. Cina Proxy can be used for the local testing of webpages or to build an Intranet. The Web-Server Plug-In supports CGI(PHP3 / 4) scripting.

The Cina Proxy is not a router and does not perform NAT (Network Address Translation). It only works with software that be configured to communicate through a proxy / firewall. Some programs can be persuaded to cooperate by using 3rd party utilities such as sockscap.

The project tells you how to build up a free proxy server for your little lan (up to 6 users tested) with a gnu gpl proxy written in vb 6.0. Features are: http-proxy, web-server (php-support,XML-support,dir),socks5,smtp relay, telnet-port-mapping, internet-mail support,remote admin via Crypto API, atomic syncer, dyndns updater and many many more (full details see below) techniques used: winsock.ocx, crypto api, msxml, Java, rasapi, ...

The Cina Proxy Server a multifunctional proxy project completly written in vb6. project life time more than 2 years. good combination of techniques and algorithms shown in serveral other projects that have same aims. the project is just a tutorial how to design a smart proxy for your lan. it is not a solution, but it can solve serveral problems that might not sell your firewall. This project is just in alpha release phase, but if you are interested in proxy programming send your feedback. if this project could not been run on your machine please report it - it has been developed on a german w2k-os.

This project is in subject to change and the online site will be modified in the future.
Please be advised that I'm currently in the process of rewriting large portions of the Site Documentation collection.
This document is slated to be replaced with new content. The content within this document is not necessarily 
up-to-date. Please watch for an updated version of this document to appear in coming weeks. 

All information about the internet and its protocols can be found in RFC documents which are freely available on the net - use your search engine. I learned network programming from try and error and the SDK.

As I do not want others to be able to sell the Cina Proxy as an expensive product, I am using the GNU General Public License.
BUT see the details of this license.

Installation instructions
-------------------------

register the 'cXPLib.dll' with the 'regsvr32.exe' -Tool:
you will find the exe in 'WIN..\SYSTEM32\regsvr32.exe'.
in cmd type: regsvr32 cXPLib.dll.

register the 'ntsvc.ocx' with the 'regsvr32.exe' -Tool:
you will find the exe in 'WIN..\SYSTEM32\regsvr32.exe'.
in cmd type: regsvr32 ntsvc.ocx.
If the registration will succeed, you get the msg: registering successful.

you must have installed the dependancies of the project files: 
msvbvm60.dll (Visual Basic runtime) 
mscomct2.ocx and its dlls 
ntsvc.ocx (source from mircosoft or mvps.org) (must also been registered)

Known Issues
------------
the cXPLib.dll is published under the GNU GPL,
it does not permit incorporating this Library into
proprietary programs.

Changes
-------

v07_plugin
---
pr -    plugin-infrastructure enabled 
	administration and custumization is now included as activex-com
	server : cfg_service.dll
	so every plug in can use this infrastructure or get even a 	special or improved admin-tool


v07
---
pr -    Fixed some bugs, FTP-Gateway, Timeout-Performance
pr -    SMTP-RELAY improvements
pr -    Documentation
pr -    Web-Server Improvements, Bug: Documents that are 0 bytes fixed...

v06
---
pr -    ISP Proxy Provider support
        RAS-Priority List, Sort
pr -    DOCROOT integration
        Web-Server Keep-Alive Support (faster!!)
        

v05
---
pr -	cWinsock better performance and not any load problems fixed

pr -	3des password encryption (8 bytes) adapted seee above to make password storing more
	secure. not implemented in proxy yet but in library

pr -    zlib handler for http server/proxy -output as gzipped-stream (experimental)

pr -    cCryptApi Class added, to make password hashing possible

pr -	htaccess.txt file set to 'hidden' will give proper access restriction,
	but could not been viewed in dir-listing or directly

pr -	virtual path mapping to any physical path(not tested well)

pr -    first cvs source-tarball creation

v04
---
pr -    type libraries make the app not so stable under other os, so i've typed in
	all win-api decls

pr -    service available for win9x (detects atomatically os)

pr -    disable cCrypto Layer by Registry Setting

pr -    remote admin functions only available if admin is 
	logged in AND crypto layer is activated

pr -    logging (instances filtered), customizable through cILog Interface Implementation

pr -    atomic time server time.nist.gov added for GMT Time Zones

pr -    doc

pr -    tlb compiled version replaced (api-decls coded)

andy -    real english for admin by andy

pr -    winxp test- failed
	ms-xml3 instead of v4 used.
	installer could not register the dll properly, v3 is installed by default


v03
---
pr -    ip-blocker added
	virtual-path-map webserver
	ras-don't connect ! if there have been 3 unsuccessful dials before
	user-behavior via Smartremote (start ras connections and individual behavior of
	proxy per user optional)

pr -    ras-class modified (raises events)
	winsock class modified (shutdown replaced)
	http helper funcs analysed and more stable
pr -    web/http-proxy shutdown of socket raises error on getdata,
	so some files could not been properly sent.
	i modify the filter classes with a doevents loop, if all data is sent.
pr -	winsock.instances up to 1000
	winsock iptohostresolver added
	user roles added - admin/guest
	smartremote updated, more features also user / ip - profiles
	ras-module timer added
pr -    added SOCKS4 Server for compatibility

v02
---
