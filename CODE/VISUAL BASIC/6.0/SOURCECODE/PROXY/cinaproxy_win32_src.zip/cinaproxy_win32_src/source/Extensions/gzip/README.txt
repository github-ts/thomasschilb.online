gzip.exe is a stdin cgi component:

you can write to it per pipe on stdin and read the gzipped data from stdout.
use it like php:

see cFilterHttpZIP.cls for details