#include <stdio.h>
#include "zlib.h"
#include <io.h>
#include <fcntl.h>

#define BUFLEN       4096
#define MAX_NAME_LEN 1024

char *prog;

void error            OF((const char *msg));
void gz_compress      OF((FILE   *in, gzFile out));
void gz_uncompress    OF((gzFile in, FILE   *out));
void main             OF((int argc, char *argv[]));
extern void exit  OF((int));

/* ===========================================================================
 * Display error message and exit
 */
void error(msg)
    const char *msg;
{
    fprintf(stdout, "%s: %s\n", prog, msg);
    exit(1);
}

/* ===========================================================================
 * Compress input to output then close both files.
 */

void gz_compress(in, out)
    FILE   *in;
    gzFile out;
{
    char buf[1];
    int len;
    int err;
    
	for (;;) {
		len = fread(buf, 1, 1, in);

        if (ferror(in)) {
            perror("fread");
            exit(1);
        }
        if (len == 0) break;
		if (buf[0] == 26) break;
        if (gzwrite(out, buf, (unsigned)len) != len) error(gzerror(out, &err));

    }
    fclose(in);
    if (gzclose(out) != Z_OK) error("failed gzclose");
}


/* ===========================================================================
 * Uncompress input to output then close both files.
 */
void gz_uncompress(in, out)
    gzFile in;
    FILE   *out;
{
    char buf[BUFLEN];
    int len;
    int err;

    for (;;) {
        len = gzread(in, buf, sizeof(buf));
        if (len < 0) error (gzerror(in, &err));
        if (len == 0) break;

        if ((int)fwrite(buf, 1, (unsigned)len, out) != len) {
	    error("failed fwrite");
	}
    }
    if (fclose(out)) error("failed fclose");

    if (gzclose(in) != Z_OK) error("failed gzclose");
}

/* ===========================================================================
 * Usage: [-d] [-f] [-h] [-1 to -9]
 *   -d : decompress
 *   -f : compress with Z_FILTERED
 *   -h : compress with Z_HUFFMAN_ONLY
 *   -1 to -9 : compression level
 */

void main(argc, argv)
    int argc;
    char *argv[];
{
    int uncompr = 0;
    gzFile file;
    char outmode[20];

    strcpy(outmode, "wb6 ");

    prog = argv[0];
    argc--, argv++;

    while (argc > 0) {
      if (strcmp(*argv, "-d") == 0)
	uncompr = 1;
      else if (strcmp(*argv, "-f") == 0)
	outmode[3] = 'f';
      else if (strcmp(*argv, "-h") == 0)
	outmode[3] = 'h';
      else if ((*argv)[0] == '-' && (*argv)[1] >= '1' && (*argv)[1] <= '9' &&
	       (*argv)[2] == 0)
	outmode[2] = (*argv)[1];
      else
	break;
      argc--, argv++;
    }
    if (argc == 0) {

		_setmode(fileno(stdin), _O_BINARY);		/* make the stdio mode be binary */
		_setmode(fileno(stdout), _O_BINARY);		/* make the stdio mode be binary */

        if (uncompr) {
            file = gzdopen(fileno(stdin), "rb");
            if (file == NULL) error("can't gzdopen stdin");
            gz_uncompress(file, stdout);
        } else {
            file = gzdopen(fileno(stdout), outmode);
            if (file == NULL) error("can't gzdopen stdout");
            gz_compress(stdin, file);
        }
    } 
    return;
}
