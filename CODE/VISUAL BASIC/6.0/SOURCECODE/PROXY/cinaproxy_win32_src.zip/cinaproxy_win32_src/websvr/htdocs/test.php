<HTML>
<BODY>
<?php
echo "Hello" . "<b>WAIT</b>";
?>
<img src="1.gi">
<a href="myobj.php?artikel=1">Buh</a>
</BODY>
</HTML>