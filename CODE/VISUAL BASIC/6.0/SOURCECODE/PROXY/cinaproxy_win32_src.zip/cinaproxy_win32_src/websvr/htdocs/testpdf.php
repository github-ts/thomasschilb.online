<?php
class pdf{
	function pt2cm($px) {
	 return round($px / 72 * 2.54, 2);
	}
	function cm2pt($cm) {
	 return round($cm * 72 / 2.54, 0);
	}
}
$pdf = pdf_new();
pdf_open_file($pdf);
$width = pdf::cm2pt(21.0); #A4
$height= pdf::cm2pt(29.4);
pdf_begin_page($pdf, $width, $height);
pdf_set_font($pdf, "Times-Roman" ,20,"host");
$left = pdf::cm2pt(2.50);
$up   = pdf::cm2pt(29.5 - 2.50);
pdf_set_text_pos($pdf,$left,$up);

pdf_show($pdf, "PDF File from Php.");

pdf_end_page($pdf);
pdf_close($pdf);
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=download.pdf");
header("Content-Description: PHP Generated Data" );
echo pdf_get_buffer($pdf);
exit;
?>
