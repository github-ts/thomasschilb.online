	<html>
		<head>
			<title>Universal Upload</title>
			<style>
			BODY 	   {background-color: #ffffff; color: #1C3382; font-family: "arial"; text-decoration: "none"; font-size: 8pt}
A          {font-family: "arial"; text-shadow: "black"  }
A:link     {color: #6666FF; text-decoration: "none"  }
A:visited  {color: #6666FF; text-decoration: "none"  }
A:active   {color: #1C3382; text-decoration: "underline"  }
A:hover    {color: #1C3382; text-decoration: "underline"  }

H1		   {font-family: "arial"; text-decoration: "none"; font-size: 14pt; font-weigth: bold }
H2		   {font-family: "arial"; text-decoration: "none"; font-size: 12pt; font-weigth: bold }
H3		   {font-family: "arial"; text-decoration: "none"; font-size: 10pt; font-weigth: bold }
H4		   {font-family: "arial"; text-decoration: "none"; font-size: 8pt; font-weigth: bold }

TH		   {font-family: "arial"; text-decoration: "none"; font-size: 8pt; font-weigth: bold }
TD		   {font-family: "arial"; text-decoration: "none"; font-size: 8pt;}

.text	   {font-family: "arial"; text-decoration: "none"; font-size: 8pt }
.small	   {font-family: "arial"; text-decoration: "none"; font-size: 8pt }
.eval 	   {background-color: #eeeeee; font-family:Courier; margin-top:12pt}
.pre	   {background-color: #eeeeee; font-family:Courier; margin-top:12pt}

.tag {color:blue}
.attr {color:red}
.parm {color:green}

			</style>
		</head>
		<body>
<div class=eval>
  <h3>Universal Upload</h3>
How Many Files do you want to upload? 
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<select name="numfiles" size="1">
	<option value="1">1 File
	<option value="2">2 Files
	<option value="3">3 Files
	<option value="5">5 Files
	<option value="10">10 Files
</select>
<input type="Submit" value="Set Count" name="regnum">
</form>
<form enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"><?php
if (isset($_POST['regnum'])) 
{

	echo '<b>'.$_POST['numfiles'].'</b> ';
	echo $_POST['numfiles'] == '1' ? 'File can be' : 'Files can be';
	echo ' uploaded:<p>';
	for ($i=1; $i<=$_POST['numfiles']; $i++)
	{
		echo "<input type=\"File\" name=\"myfile$i\"><br>\n";
	}
	echo '<p>';
	echo '<input type="Submit" name="sendfiles" value="Send Files">';
}
if (isset($_REQUEST['sendfiles']))
{
	$numsendfiles = count($_SERVER['HTTP_POST_FILES']);
	echo "<b>$numsendfiles</b> ";
	echo $numsendfiles == 1 ? 'File has' : 'Files have';
	echo ' been sent.<p>';
	foreach($_SERVER['HTTP_POST_FILES'] as $strFieldName => $arrPostFiles)
	{
		if ($arrPostFiles['size'] > 0) // if upload was successfully
		{
			// catch data
			$strFileName = $arrPostFiles['name'];
			$intFileSize = $arrPostFiles['size'];
			$strFileMIME = $arrPostFiles['type'];
			$strFileTemp = $arrPostFiles['tmp_name'];
			copy ($strFileTemp, "upload/$strFileName");
			echo "Datei <b>$strFileName</b> sucessfully uploaded:";
			echo "<ul>";
			echo "<li>Size: $intFileSize Bytes<br>";
			echo "<li>MIME: $strFileMIME<br>";
			echo "</ul>";
		}  /* end if */
	} /* end foreach */
}
?></form>
</div>
</body>
</html>