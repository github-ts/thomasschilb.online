<?php
$breite=200;
$hoehe=80;
$img=imagecreate($breite,$hoehe);
$vcolor=imagecolorallocate($img,255,255,255);
$bcolor=imagecolorallocate($img,0,0,0);
imagerectangle($img,0,0,199,79, $bcolor);
imagerectangle($img,0,0,197,77, $bcolor);
$text = "go...";
imagettftext($img,36,0,20,50,$bcolor, $_SERVER['SystemRoot'].'\Fonts\verdana.ttf', $text);
header ("Content-type: image/png");
imagepng($img);
imagedestroy($img);
?>
