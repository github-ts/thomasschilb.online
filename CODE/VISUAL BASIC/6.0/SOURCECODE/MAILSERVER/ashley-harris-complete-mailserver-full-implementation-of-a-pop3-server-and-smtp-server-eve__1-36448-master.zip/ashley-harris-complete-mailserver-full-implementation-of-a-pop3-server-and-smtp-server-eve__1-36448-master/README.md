﻿<div align="center">

## Complete mailserver\! Full implementation of a POP3 server and SMTP server\! EVEN a webmail interface\!


</div>

### Description

An SMTP server, POP3 server, and Webmail service! All written in pure VB6! Ideal for a small-medium company with a spare machine sitting around! Unlimited # of mailboxes! Works directly with outlook, or any other email client, and supports everything that a large server does, even SMS notification and account sizes (ie bounced messages saying 'sorry, account is over quota' (also SMS's you when your account is over quota)). Email to/from other dommains, ie, someone at hotmail can send an email to 'me@mydommain.com', and it'll arive in my maildrop, ready to be downloaded into my email client or view via the webmail. It works just like a normal server, ie, it doesn't try to send an email once, fail, and give up, it tries for hours, giving status reports after the first try, 4 hours, and 4 days. The webmail has some missing features (it was a 2AM to 5:30AM Job), ie reply/forward/attachment support, but these are all supported by the POP3/SMTP servers. Even secure passwords are supported by this server! Check it out!
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2002-06-30 21:50:54
**By**             |[Ashley Harris](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/ashley-harris.md)
**Level**          |Intermediate
**User Rating**    |4.8 (540 globes from 112 users)
**Compatibility**  |VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Complete\_m100829712002\.zip](https://github.com/Planet-Source-Code/ashley-harris-complete-mailserver-full-implementation-of-a-pop3-server-and-smtp-server-eve__1-36448/archive/master.zip)








