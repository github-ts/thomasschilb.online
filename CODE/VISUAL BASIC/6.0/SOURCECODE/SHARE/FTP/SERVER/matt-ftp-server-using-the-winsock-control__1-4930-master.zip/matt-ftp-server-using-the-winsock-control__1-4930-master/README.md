﻿<div align="center">

## FTP Server using the Winsock control


</div>

### Description

This is a simple FTP server I developed using the Winsock control. Its got a few bugs in it that need to be solved as well as some missing features. But I think you will find this useful. It is more complete than any other FTP servers posted here. Its got plenty of comments so I hope it is easy to follow.

If you make any additions or improvments please let me know. Would be neet if we could make this sort of a collaborative effort towards a decent FTP server.

Updated: *FIXED sending files to the client. (FINALLY!)
 
### More Info
 
Understanding of how FTP works.


<span>             |<span>
---                |---
**Submitted On**   |1999-12-17 00:22:22
**By**             |[Matt\*](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/matt.md)
**Level**          |Advanced
**User Rating**    |4.7 (42 globes from 9 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Miscellaneous](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/miscellaneous__1-1.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[CODE\_UPLOAD237412161999\.zip](https://github.com/Planet-Source-Code/matt-ftp-server-using-the-winsock-control__1-4930/archive/master.zip)








