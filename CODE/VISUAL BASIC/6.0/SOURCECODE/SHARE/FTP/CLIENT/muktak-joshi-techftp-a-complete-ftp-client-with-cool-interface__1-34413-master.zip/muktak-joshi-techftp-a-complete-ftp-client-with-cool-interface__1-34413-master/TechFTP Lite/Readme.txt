Hi, I am Muktak Joshi. I am 19 years old. I am studying in AISSMS College of Engineering Pune (doing Mechanical Engineering). This is my first submission to any Code site.

To know more about me see http://www.techprotean.com/muktak

Please mail your Sugestions Comments at muktak@techprotean.com

